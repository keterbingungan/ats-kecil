"""
Simple script to test the NER model directly.
Run this to see how the model extracts skills from sample text.
"""

import json
import numpy as np
from transformers import DistilBertTokenizerFast, TFDistilBertForTokenClassification

# ==========================================
# CONFIGURATION
# ==========================================
MODEL_PATH = "./best_distilbert_model"
METADATA_PATH = "./metadata.json"

# ==========================================
# LOAD MODEL
# ==========================================
print("🚀 Loading model...")
tokenizer = DistilBertTokenizerFast.from_pretrained(MODEL_PATH)
model = TFDistilBertForTokenClassification.from_pretrained(MODEL_PATH)

with open(METADATA_PATH, "r") as f:
    metadata = json.load(f)
    tag2idx = metadata.get("tag2idx", {"O": 0, "B-SKILL": 1, "I-SKILL": 2})

idx2tag = {v: k for k, v in tag2idx.items()}
print(f"✅ Model loaded! Tags: {tag2idx}\n")

# ==========================================
# TEST FUNCTION
# ==========================================
def extract_skills(text: str, show_details: bool = True):
    """Extract skills from text and show the process."""
    
    # Tokenize
    encoding = tokenizer(
        text,
        truncation=True,
        max_length=256,
        padding="max_length",
        return_tensors="tf",
        return_offsets_mapping=True
    )
    
    offset_mapping = encoding.pop("offset_mapping").numpy()[0]
    
    # Run inference
    outputs = model(**encoding)
    predictions = outputs.logits.numpy()
    predicted_ids = np.argmax(predictions, axis=-1)[0]
    
    # Show token-by-token predictions
    if show_details:
        print("=" * 60)
        print("TOKEN-BY-TOKEN ANALYSIS:")
        print("=" * 60)
        print(f"{'TOKEN':<20} {'TAG':<15} {'OFFSET'}")
        print("-" * 60)
    
    skills = []
    current_skill = []
    
    for idx, pred_id in enumerate(predicted_ids):
        start, end = offset_mapping[idx]
        
        # Skip special tokens
        if start == 0 and end == 0:
            if current_skill:
                skill_text = "".join(current_skill).strip()
                if skill_text:
                    skills.append(skill_text)
                current_skill = []
            continue
        
        tag = idx2tag.get(pred_id, "O")
        token_text = text[start:end]
        
        if show_details and tag != "O":
            print(f"{token_text:<20} {tag:<15} ({start}, {end})")
        
        if tag == "B-SKILL":
            if current_skill:
                skill_text = "".join(current_skill).strip()
                if skill_text:
                    skills.append(skill_text)
            current_skill = [token_text]
        elif tag == "I-SKILL" and current_skill:
            current_skill.append(token_text)
        else:
            if current_skill:
                skill_text = "".join(current_skill).strip()
                if skill_text:
                    skills.append(skill_text)
                current_skill = []
    
    if current_skill:
        skill_text = "".join(current_skill).strip()
        if skill_text:
            skills.append(skill_text)
    
    # Remove duplicates
    unique_skills = list(dict.fromkeys(skills))
    
    return unique_skills

# ==========================================
# TEST CASES
# ==========================================

# Test 1: Simple skill mention
test1 = "I have experience with Python and JavaScript"
print("\n" + "=" * 60)
print("TEST 1: Simple skill mention")
print("=" * 60)
print(f"Input: {test1}")
skills1 = extract_skills(test1)
print(f"\n✅ Extracted Skills: {skills1}\n")

# Test 2: Technical CV-like text
test2 = """
Experienced software developer with 5 years of experience in Python, 
JavaScript, React, Node.js, and PostgreSQL. Proficient in Docker, 
Kubernetes, and AWS cloud services. Strong knowledge of REST APIs 
and microservices architecture.
"""
print("\n" + "=" * 60)
print("TEST 2: CV-like paragraph")
print("=" * 60)
print(f"Input: {test2.strip()}")
skills2 = extract_skills(test2)
print(f"\n✅ Extracted Skills: {skills2}\n")

# Test 3: Skills section format
test3 = """
Skills:
- Python
- Machine Learning
- TensorFlow
- Deep Learning
- NLP
"""
print("\n" + "=" * 60)
print("TEST 3: Skills list format")
print("=" * 60)
print(f"Input: {test3.strip()}")
skills3 = extract_skills(test3)
print(f"\n✅ Extracted Skills: {skills3}\n")

# Test 4: Mixed sentence
test4 = "Developed web applications using FastAPI and deployed on AWS using Docker containers"
print("\n" + "=" * 60)
print("TEST 4: Action-based sentence")
print("=" * 60)
print(f"Input: {test4}")
skills4 = extract_skills(test4)
print(f"\n✅ Extracted Skills: {skills4}\n")

# ==========================================
# INTERACTIVE MODE
# ==========================================
print("\n" + "=" * 60)
print("INTERACTIVE MODE")
print("=" * 60)
print("Enter your own text to test (type 'quit' to exit):\n")

while True:
    user_input = input("Enter text: ")
    if user_input.lower() in ['quit', 'exit', 'q']:
        break
    
    if user_input.strip():
        skills = extract_skills(user_input)
        print(f"\n✅ Extracted Skills: {skills}\n")
